import web3 from "./web3";
import CampaignFactory from "./build/CampaignFactory.json";

const instance = new web3.eth.Contract(
  JSON.parse(CampaignFactory.interface),
  "0x2957D7fD280B82E2eF583216639ac062E57e65E0"
);

export default instance;
